# mikicaChessEngine

An original chess engine written in Rust, developed as a measured engine-research project with a long-term target of strong CCRL-style long-time-control play.

## Status

Current milestone: **v0.3.0 stable single-thread UCI release**.

The release extends the stable v0.2 line with measured selective-search
improvements, a thread-safe transposition table, incremental pawn state and a
reproducible hard-position benchmark. It remains intentionally single-threaded.

### Strength evidence

The v0.3.0 release candidate was compared directly with the locked v0.2.0
build:

```text
400 games, 2+0.02:
168 W / 125 L / 107 D
+37.49 Elo +/- 28.14
LOS 99.58%

100 games, 5+0.05:
48 W / 28 L / 24 D
+70.44 Elo +/- 48.46
LOS 99.84%
```

Against the pre-improvement baseline, the production chess code previously achieved:

```text
500 games, 1+0.01:
240 W / 110 L / 150 D
+92.46 Elo +/- 24.94
LOS 100.00%
```

The v0.2.0 line was compared directly with the locked `release/v0.1.0` build
after the new time manager was introduced:

```text
200 games, 1+0.01:
76 W / 72 L / 52 D
+6.95 Elo +/- 25.95

100 games, 5+0.05:
37 W / 38 L / 25 D
-3.47 Elo +/- 47.96
```

Neither test shows a meaningful strength regression.

### Stability evidence

- 5,000/5,000 Fastchess self-play games completed with crash recovery disabled.
- Fastchess UCI compliance passed before and after the 5,000-game soak.
- Official Cute Chess 1.5.1 completed two full repeating `40/15:00` self-play
  games without time loss, illegal move, crash or protocol failure; the games
  lasted 74 and 83 full moves and the engine restarted cleanly afterward.
- Linux and Windows generic/Haswell release builds are required to execute real UCI startup smoke tests before packaging.
- Every release package contains build metadata and a SHA-256 checksum for its engine binary.

## Implemented and production-tested

- UCI: `uci`, `isready`, `ucinewgame`, `position`, `go`, `stop`, `quit`
- UCI `Hash` option, 1-4096 MB
- UCI `Move Overhead` option with explicit tournament-time safety reserve
- `Threads` is deliberately advertised as `min 1 max 1`
- asynchronous search worker so the UCI input loop stays responsive
- explicit stdout flushing for GUI communication
- transactional `position ... moves` application: invalid move sequences do not partially mutate the active position
- FEN parsing and serialization with stricter king/fullmove validation
- legal move generation
- castling, en-passant and promotions
- make/unmake
- deterministic randomized make/unmake/FEN/Zobrist/evaluation property coverage
- perft test harness
- iterative deepening
- PVS / alpha-beta search
- quiescence search
- lock-free atomic transposition table safe for future shared-search experiments
- mate-score normalization for TT reuse at different plies
- threefold repetition tracking from UCI game history plus the search path
- 50-move draw handling with checkmate precedence
- MVV-LVA capture ordering
- killer moves and history heuristic
- guarded null-move pruning with verification at deeper nodes
- conservative reverse futility pruning
- fail-soft aspiration windows
- handcrafted phase-aware evaluation
- rook open/semi-open-file evaluation
- phase-scaled king pawn-shield evaluation
- repeating-control-aware clock allocation using `movestogo`
- deterministic search benchmark
- deterministic fixed-node EPD/STS benchmark runner
- paired Fastchess strength testing on the pinned official Stockfish opening suite
- pinned Fastchess and opening-book source revisions for research reproducibility
- pinned official Cute Chess compatibility binary with SHA-256 verification
- Rust 1.97.1 toolchain pin locally and in every GitHub workflow
- blocking rustfmt, strict Clippy, release tests, perft and deterministic benchmark in CI
- interactive UCI handoff testing of exact release binaries
- Linux and Windows x86-64 generic + Haswell/AVX2 release packages

The production depth-4 deterministic benchmark remains:

```text
bench total_nodes 40202 checksum 2476681a0e3df97d
```

## Deliberately not advertised in v0.3.0

- `Threads > 1`: the first safe independent-worker SMP prototype was measured and rejected. On a 2-CPU CI runner, `Threads=4` lost 17-134-49 to `Threads=1` over 200 games (`-232.79 +/- 47.50 Elo`). It is research code, not a release capability.
- engine-side Syzygy probing: not implemented in this release and not represented as implemented.
- internal opening book or persistent learning: intentionally absent.
- NNUE and newer selective-search techniques: future strength work, not production claims.

The rule for this repository is simple: **a capability is not advertised until it works and has an appropriate correctness, protocol, stability or strength test.**

## Build

The repository pins Rust 1.97.1.

```bash
cargo build --release
```

Run:

```bash
./target/release/mikicaChessEngine
```

Haswell/AVX2-oriented build:

```bash
RUSTFLAGS="-C target-cpu=haswell" cargo build --release
```

## Recommended v0.3.0 tournament settings

- `Threads=1`
- pondering off
- tester-controlled `Hash`
- `Move Overhead=30` ms by default; increase it on high-latency or heavily loaded systems
- use the generic x86-64 package unless the test machine is known to support the Haswell/AVX2 build

## Verify

```bash
cargo fmt --all -- --check
cargo check --all-targets
cargo clippy --all-targets --all-features -- -D warnings
cargo test --release
```

Core regression targets include:

- start position perft depth 4: `197281`
- Kiwipete perft depth 3: `97862`
- randomized legal playout state round-trips
- make/unmake and incremental hash/evaluation consistency
- castling, en-passant and promotion
- legal search result and mate search
- mate-score TT normalization
- threefold repetition and 50-move handling
- transactional invalid `position` handling
- real-process `go infinite -> stop -> bestmove`
- real-process `movetime` and tiny-clock safety

Run the deterministic search benchmark:

```bash
cargo run --release --bin mikica-bench -- --depth 4
```

Run a scored EPD suite with an equal, reproducible node budget per position:

```bash
./scripts/fetch-sts.sh
cargo run --release --bin mikica-epd -- \
  --file testdata/STS1-STS15_LAN_v6.epd --nodes 100000 --quiet
```

See [`docs/EPD-BENCHMARKS.md`](docs/EPD-BENCHMARKS.md) for suite provenance,
scoring support and comparison rules.

## Strength-testing rule

Correctness comes first. Strength changes are measured against a fixed baseline using paired openings and statistical testing. A patch is not accepted merely because it looks sensible, reduces node count, increases reported depth, raises NPS or solves a few tactical positions.

Fastchess is rebuilt from pinned source on each runner rather than caching a native executable, because host-specific `-march=native` binaries are unsafe to move between heterogeneous CI CPUs.

## CCRL target

The v0.3.0 release is a **1CPU UCI engine**. See
[`docs/CCRL.md`](docs/CCRL.md) for the compatibility matrix,
[`docs/STABLE-RELEASE.md`](docs/STABLE-RELEASE.md) for the stable freeze and
[`docs/RELEASE-CANDIDATE.md`](docs/RELEASE-CANDIDATE.md) for the historical RC
evidence. A future 4CPU release is a separate research milestone and must prove
actual wall-clock scaling before it can replace the 1CPU configuration.

## Research focus after v0.3.0

1. cooperative SMP that is actually stronger at equal wall clock,
2. efficient and safe selective search,
3. engine-side Syzygy as an isolated optional feature,
4. efficient NNUE,
5. learned cutoff-cost move ordering and search allocation,
6. reproducible automated engine experiments.

## Documentation

- [`docs/CCRL.md`](docs/CCRL.md) — CCRL target, constraints and readiness checklist
- [`docs/STABLE-RELEASE.md`](docs/STABLE-RELEASE.md) — exact v0.3.0 stable freeze and promotion evidence
- [`docs/RELEASE-CANDIDATE.md`](docs/RELEASE-CANDIDATE.md) — historical v0.3.0-rc.1 freeze and evidence
- [`docs/TESTING.md`](docs/TESTING.md) — correctness, benchmark, paired-match and statistical testing protocol
- [`docs/EPD-BENCHMARKS.md`](docs/EPD-BENCHMARKS.md) — hard-position EPD/STS benchmark workflow
- [`docs/ROADMAP.md`](docs/ROADMAP.md) — implementation phases
- [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) — current and target architecture
- [`docs/RESEARCH.md`](docs/RESEARCH.md) — research hypotheses and experiment discipline
- [`docs/EXPERIMENTS.md`](docs/EXPERIMENTS.md) — early experiment ledger
- [`docs/RESEARCH-RESULTS-2026-08.md`](docs/RESEARCH-RESULTS-2026-08.md) — measured strength/rejection history
- [`CONTRIBUTING.md`](CONTRIBUTING.md) — rules for changes and Elo experiments
