# Research results — August 2026

This document continues the experiment history after `docs/EXPERIMENTS.md` and records the selective-search, evaluation, hardening and SMP campaign.

All serious strength tests use paired games with reversed colors, the official Stockfish `8moves_v3.pgn` opening suite pinned at books commit `65815ccdbc7727cd4f6aee252ba8f67fb740e92f`, and Fastchess pinned at `74deac23aadc6718fa0f8e24ac95d16392d79444`.

## E003 — conservative late-move reductions

**Decision:** `REJECT`

LMR was enabled for later quiet non-checking moves, initially from depth 4, with one-ply reductions and a two-ply reduction for deeper/later moves. Search instrumentation showed that move ordering was already reasonably effective: at depth 7 there were 1,048 reduced searches, only 12 reduced-search re-searches, and only 2 cases where a reduced move ultimately improved the best score.

A 200-game diverse-opening confirmation did not establish a strength gain, and the longer-time-control proxy was neutral. The tree reduction was real, but tree size alone is not a merge criterion.

## E003b — LMR from depth 3, R1/R2

**Decision:** `REJECT`

Depth-4 benchmark changed from roughly 64.6k nodes to 57,753 nodes, about a 10.6% tree reduction.

Evidence:

```text
40 games, 1+0.01: 13 W / 12 L / 15 D, about +8.7 Elo
200 games, 1+0.01: 66 W / 62 L / 72 D, +6.95 Elo +/- 37.75
40 games, 5+0.05: 10 W / 13 L / 17 D, -26.1 Elo +/- 100.4
```

The node reduction did not convert into demonstrated strength.

## E003c — LMR from depth 3, capped at R1

**Decision:** `INCONCLUSIVE`

The only chess difference from E003b was removing the deeper two-ply reduction. Correctness gates passed and the depth-4 benchmark remained 57,753 nodes because R2 only activates deeper in the tree.

```text
40 games, 1+0.01: 14 W / 13 L / 13 D, +8.69 Elo +/- 75.31
```

No signal justified a larger test at this stage.

## E004 — pawn-structure evaluation

**Decision:** `REJECT`

Tested doubled-pawn, isolated-pawn and passed-pawn terms.

The implementation was expensive and weak:

```text
depth-4 nodes: 85,994, about +33% versus baseline
40 games, 1+0.01: 13 W / 17 L / 10 D, -34.9 Elo +/- 84.5
```

Do not retry this exact full-board implementation. A future pawn model should be incremental, cached, or learned from data.

## E005 — lightweight piece mobility

**Decision:** `INCONCLUSIVE`

Tested simple pseudo-mobility weights for knight, bishop, rook and queen.

```text
depth-4 nodes: 69,816, about +8%
40 games, 1+0.01: 14 W / 11 L / 15 D, +26.1 Elo +/- 79.0
```

The screen was positive but the evaluation cost was materially higher than the cheaper rook-file and king-shield candidates. Keep as a possible future follow-up rather than production code.

## E006 — rook open and semi-open files

**Decision:** `CONFIRMED POSITIVE`; retained as a safe fallback

Mechanism:

- rook on open file: +14 cp;
- rook on semi-open file: +8 cp;
- no bonus if a friendly pawn occupies the file.

The feature is cheap and produced a strong reproducible result.

```text
40 games, 1+0.01: 13 W / 10 L / 17 D, +26.1 Elo +/- 74.9
200 games, 1+0.01: 94 W / 60 L / 46 D, +59.64 Elo +/- 37.67, LOS 99.93%
40 games, 5+0.05: 19 W / 14 L / 7 D, +43.66 Elo +/- 78.21, LOS 86.97%
```

No crashes, illegal moves or UCI failures were observed.

## E007 — phase-scaled king pawn shield

**Decision:** `REJECT AS STANDALONE`; useful in combination

Mechanism:

For a king on relative rank 0–2, inspect the king file and adjacent files. The nearest friendly pawn receives a shield score of +12 on relative rank 1, +8 on rank 2, or +3 on rank 3. The term is scaled by game phase.

```text
40 games, 1+0.01: 18 W / 14 L / 8 D, +34.9 Elo +/- 95.3
200 games, 1+0.01: 82 W / 62 L / 56 D, +34.86 Elo +/- 44.59, LOS 93.97%
40 games, 5+0.05: 13 W / 14 L / 13 D, -8.69 Elo +/- 93.88
```

Short-time-control evidence was positive, but the standalone term was not confirmed at the longer proxy. Do not merge E007 alone.

## E008 — rook files + king pawn shield

**Decision:** `MERGE`

This combines E006 and E007 without changing search. The two inexpensive positional features interacted better than either standalone candidate.

Correctness gates passed: compiler, strict Clippy, release tests, perft, randomized make/unmake, incremental evaluation validation and Fastchess UCI compliance.

Deterministic depth-4 benchmark:

```text
total_nodes 68245
checksum d657bcfa5720cdb4
```

Strength evidence:

```text
40 games, 1+0.01:
18 W / 10 L / 12 D
+70.44 Elo +/- 86.58
LOS 95.31%

200 games, 1+0.01:
93 W / 44 L / 63 D
+86.89 Elo +/- 40.38
LOS 100.00%
Ptnml [4, 15, 31, 28, 22]

40 games, 5+0.05:
20 W / 9 L / 11 D
+98.07 Elo +/- 77.36
LOS 99.62%
Ptnml [1, 0, 9, 7, 3]
```

The positive signal strengthened rather than reversed at the longer time control. The clean release patch was merged through PR #5.

## E009 — naive independent-worker SMP

**Decision:** `REJECT`

A safe first `Threads=1..4` prototype used independent `Searcher` instances, split the configured hash budget across workers, shared only an atomic stop flag, and retained the primary worker between moves. Helper workers were intentionally isolated to avoid data races and unsafe shared mutation.

Correctness and protocol tests passed, including real `Threads=4` UCI search and cancellation. That was not sufficient for merge: the configuration had to prove useful wall-clock scaling.

The GitHub-hosted validation runner exposed only two CPU cores. On that environment a four-worker candidate was tested against the same binary with `Threads=1`, equal wall-clock time control and equal total configured hash:

```text
200 games, 1+0.01
Threads=4: 17 W / 134 L / 49 D
score: 20.75%
Elo: -232.79 +/- 47.50
LOS: 0.00%
```

The result is decisively negative. Independent workers duplicate too much search, oversubscribe the available CPU and do not cooperate through a shared transposition table or root work distribution.

Permanent rule: **do not merge or advertise this SMP design**. A future 4CPU attempt must be a new experiment using real parallel search cooperation (for example shared TT plus root/search diversification) and must be tested on a runner with at least four physical/logical CPUs assigned to the process. Merely starting four workers is not evidence of SMP strength.

## E010 — incremental passed-pawn evaluation

**Decision:** `INCONCLUSIVE / REJECT FOR NOW`

E010 revisited only the passed-pawn part of the rejected E004 pawn-structure experiment. Before testing the chess term, production `main` gained behavior-preserving incremental pawn bitboards and the existing rook-file and king-shield evaluation was switched to bitboard lookups. Both infrastructure changes preserved the deterministic benchmark exactly.

The E010 candidate deliberately avoided doubled- and isolated-pawn terms. A pawn was classified as passed when no enemy pawn existed ahead of it on the same or adjacent file. The rank bonuses were conservative (`[0, 0, 3, 7, 14, 26, 45, 0]`) and phase-scaled from half value in the full middlegame to full value in a pure endgame.

Correctness gates passed: formatting, compiler, strict Clippy, release tests, start-position perft, deterministic benchmark and Fastchess UCI compliance.

The term nevertheless made the search tree materially larger:

```text
main total_nodes: 40,367
E010 total_nodes: 47,955
change: +18.8%

main Kiwipete: 21,377
E010 Kiwipete: 28,981
change: +35.6%
```

Strength evidence was consistently positive but not strong enough to pay for that search cost:

```text
screen — 40 games, 1+0.01, seed 1:
23 W / 11 L / 6 D
+107.54 Elo +/- 87.63
LOS 99.57%

confirmation — 200 games, 2+0.02, seed 2:
83 W / 70 L / 47 D
+22.62 Elo +/- 35.21
LOS 89.74%
Ptnml [8, 12, 50, 19, 11]

confirmation — 200 games, 2+0.02, seed 3:
74 W / 65 L / 61 D
+15.65 Elo +/- 36.27
LOS 80.23%
Ptnml [6, 23, 38, 22, 11]
```

The two 200-game confirmations total 400 games at the same time control and both point in the positive direction (`157 W / 135 L / 108 D`, 52.75% score), but the estimated gain remains modest and the uncertainty is still material. This does not justify a feature that expands the measured depth-4 tree by almost one fifth.

Permanent rule: **do not merge E010 in its current form**. If passed pawns are revisited, first make the feature substantially cheaper (for example precomputed masks, cached/incremental pawn evaluation, or a tuned learned evaluator), then re-test from a clean branch. Do not add doubled/isolated terms at the same time.

## E017 — guarded late-move reductions revisit

**Decision:** `REJECT`

E017 revisited the old E003 LMR idea after the production search gained explicit
cut-node propagation, guarded null-move pruning, aspiration windows and stronger
move ordering. Only late quiet, non-checking moves were eligible; killer moves
and moves with history score at least 64 were protected. A reduced move that
beat alpha was re-searched at full depth.

E017a used one-ply reductions plus a deeper/later two-ply reduction. It passed
correctness and UCI compliance, but its 200-game screen was neutral:

```text
E017a, 200 games, 2+0.02, seed 2, 1 thread, 32 MB:
73 W / 72 L / 55 D
+1.74 Elo +/- 32.57
LOS 54.17%
Ptnml [6, 20, 48, 19, 7]
```

E017b removed the two-ply reduction and capped every eligible reduction at one
ply. The deterministic search tree became much smaller while depth-4 behavior
remained identical:

```text
depth 4 main and E017b: 40,202 nodes, checksum 2476681a0e3df97d

depth 6 main:   371,728 nodes
depth 6 E017b:  239,514 nodes
change:         -35.6%
```

At depth 6 all four benchmark positions retained the same score and best move.
At depth 8 E017b used 2,571,680 nodes versus 4,820,221 on main (-46.6%), but
the start-position best move and closed-center score/best move changed. The
paired strength result did not validate the extra selectivity:

```text
E017b, 200 games, 2+0.02, seed 2, 1 thread, 32 MB:
72 W / 74 L / 54 D
-3.47 Elo +/- 35.17
LOS 42.30%
Ptnml [10, 18, 42, 24, 6]
```

Evidence runs:

- E017a strength: <https://github.com/oaki/mikicaChessEngine/actions/runs/31785474879>
- E017b correctness/bench: <https://github.com/oaki/mikicaChessEngine/actions/runs/31785922460>
- E017b strength: <https://github.com/oaki/mikicaChessEngine/actions/runs/32817146446>

The experiment achieved substantial deterministic tree reduction but no
playing-strength signal in either variant. Do not merge the experiment build
harness or LMR patch. Preserve branch `experiment/e017-guarded-lmr` as research
history. A future LMR attempt must be materially different (for example a tuned
depth/move-count table modulated by richer continuation history) and must earn
its place through a new paired statistical test.

## Strength-infrastructure incident — never cache native Fastchess binaries

A 200-game confirmation attempt failed before games started with `Illegal instruction` after restoring a cached Fastchess executable. Fastchess's build can use host-specific CPU instructions (`-march=native`), so an executable built on one GitHub runner is not safe to reuse on a runner with a different CPU feature set.

Permanent rule:

- pin the Fastchess source commit;
- build Fastchess on the current runner;
- never cache and restore the compiled Fastchess binary across heterogeneous runners.

The failed run was treated as infrastructure failure, not chess evidence.

## Research rules reinforced by this campaign

1. A smaller search tree is not proof of a stronger engine.
2. Forty games are only a screen.
3. Repeated tiny opening sets can manufacture false confidence; use a large pinned opening suite.
4. A short-time-control gain must survive a longer-time-control sanity gate before merge.
5. Keep experiments isolated: one causal hypothesis per branch where possible.
6. Preserve failed experiments so automated research does not rediscover the same dead ends.
7. Cheap evaluation features can outperform complex pruning work when the baseline evaluator is still immature.
8. Production merges must come from a clean branch containing only the verified chess delta.
9. A feature can be protocol-correct and still be performance-wrong; SMP requires a strength/scaling gate, not just a concurrency test.
10. A positive Elo direction is not enough when an evaluation term materially expands the search tree; strength must justify its computational cost.
