# Hard-position EPD benchmarks

`mikica-epd` runs reproducible searches over Extended Position Description
(EPD) suites. Its primary use is diagnosing tactical/strategic regressions and
comparing search quality at equal work. It does **not** establish Elo and never
replaces paired Fastchess games.

## Recommended suite: STS v6

The Strategic Test Suite (STS) is used by multiple chess engines and testing
tools. The maintained `STS-Rating` repository provides 1,188 filtered positions
with coordinate moves and 1–100 point weights derived from a Stockfish 15
multi-PV analysis. The repository is MIT-licensed.

The fetch helper pins both the upstream commit and file SHA-256; the downloaded
suite is deliberately ignored by Git so upstream data is not silently vendored:

```bash
./scripts/fetch-sts.sh
```

Pinned source:

```text
repository: https://github.com/fsmosca/STS-Rating
commit:     4e36977090c3a93ea57d5f34e13e42df422634d3
file:       epd/STS1-STS15_LAN_v6.epd
positions:  1188
sha256:     8638fdf0d0355cd498cb8002ca95feb7e9db0f5f6eb6fc9926be04a6e83673a6
license:    MIT
```

## Deterministic comparison

Use a fixed node count for candidate-versus-baseline comparisons:

```bash
cargo run --release --bin mikica-epd -- \
  --file testdata/STS1-STS15_LAN_v6.epd \
  --nodes 100000 \
  --hash 64 \
  --quiet
```

Record the exact engine commit, Rust version, suite commit/checksum, hash size,
node budget, total points, solved count, elapsed time and NPS. Run both builds on
the same otherwise-idle machine. Fixed nodes make the search-work budget
reproducible; elapsed time and NPS remain hardware/load dependent.

Initial production-search baseline (Rust 1.97.1, 1 thread, 64 MB, 100,000 nodes
per position):

```text
positions=1188
solved=412
points=69881/118800
score_pct=58.822
total_nodes=118800000
```

The point total, solved count and node total are the portable regression values.
Do not copy the measured time/NPS to another machine as a performance target.

For a quick smoke test before a full 1,188-position run:

```bash
cargo run --release --bin mikica-epd -- \
  --file testdata/STS1-STS15_LAN_v6.epd \
  --nodes 10000 \
  --limit 20
```

`--depth D` is useful for search-tree diagnosis and `--movetime-ms MS` resembles
traditional tactical-suite runs, but only `--nodes N` gives the same work budget
across machines. The three budget options are mutually exclusive.

## Supported EPD scoring

The runner accepts standard four-field EPD positions and:

- `bm` best moves, in UCI coordinate or common SAN notation;
- `am` avoid moves;
- `id` labels;
- weighted `c0` entries such as `Ne5=10, Nd4=8`;
- STS v6 `c9` coordinate moves paired with integer `c8` scores.

Each position starts with a fresh transposition table so results do not depend on
suite order. Output includes each best move, completed depth, exact node count,
time and score, followed by one stable `epd summary` line suitable for CI logs.

## What other projects do

- Arasan has a built-in command that searches EPD suites at fixed depth or fixed
  time; its current source and bundled tests are MIT-licensed.
- Chess Programming Wiki recommends a small tactical suite such as WAC as a
  regression warning after important search changes.
- Stockfish development relies primarily on deterministic bench plus large
  paired statistical tests. Its official CC0 books are appropriate opening
  sources for matches, not scored best-move tests.

The project therefore uses all three evidence layers: perft/correctness,
fixed-work EPD diagnostics, and paired statistical games for strength decisions.
