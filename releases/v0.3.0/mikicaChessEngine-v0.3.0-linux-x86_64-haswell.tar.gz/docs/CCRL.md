# CCRL 40/15 readiness

This document turns the CCRL 40/15 target into explicit engineering requirements. It should be updated whenever the official CCRL methodology changes.

Official methodology: https://computerchess.org.uk/4040/about.html

## Target environment

The current CCRL 40/15 methodology describes a time control calibrated to the equivalent of **40 moves in 15 minutes on an Intel i7-4770K**, repeating after every 40 moves. Pondering is disabled. CCRL supplies a common generic opening book, with a maximum of 12 moves per side, and disables engine-specific books and learning. Endgame tablebases cover 4-6 pieces. Hash is standardized by the testers; 4-CPU engines may receive proportionally more hash than a single-CPU engine.

mikicaChessEngine v0.3.0 is intentionally a **1CPU engine**. A future 4CPU configuration is a separate strength/scaling project and is not claimed until it passes its own gates. The v0.2.0 results below remain historical evidence; current release evidence is frozen separately in `docs/STABLE-RELEASE.md`.

## Compliance matrix

| Requirement | Status | mikicaChessEngine v0.3.0 |
|---|---|---|
| UCI executable | PASS | Rust UCI binary builds and is exercised end-to-end in CI |
| `uci` / `isready` | PASS | Implemented and stdout is explicitly flushed |
| legal `position startpos` / FEN | PASS | Implemented; deterministic randomized FEN/hash/eval/make-unmake round-trips run in CI |
| invalid `position ... moves` safety | PASS | Position application is transactional; an illegal move sequence leaves the active board unchanged |
| repeating long-time-control clock parsing | PASS | `wtime/btime/winc/binc/movestogo` are parsed; allocator reserves configurable move overhead; Cute Chess completed two full repeating `40/15:00` games without time loss |
| `Move Overhead` option | PASS | UCI spin option, default 30 ms, with fixed-movetime/tiny-clock process tests |
| pondering disabled | PASS | Engine does not ponder |
| `Hash` option | PASS | Configurable, 1-4096 MB |
| stable `stop` command | PASS | Atomic cancellation is process-tested with `go infinite -> stop -> bestmove` |
| `Threads=1` | PASS | Verified production configuration and the only thread count advertised by v0.3.0 |
| `Threads>1` | NOT ADVERTISED | First independent-worker prototype was rejected after a decisive negative scaling/strength test |
| repetition / 50-move correctness | PASS | UCI game history is preserved; threefold and 50-move claims are handled with checkmate precedence |
| mate-score TT normalization | PASS | Mate scores are normalized on TT store/probe and unit tested |
| engine-side Syzygy probing | NOT IN v0.3.0 | Deliberately not represented as an implemented feature; tester-side tablebase policy remains external |
| engine-specific book disabled | PASS | No internal opening book |
| book/position learning disabled | PASS | No learning state is persisted |
| deterministic clean startup | PASS | UCI subprocess tests plus Fastchess compliance before/after soak and Cute Chess post-tournament restart |
| generic x86-64 release binary | PASS | Linux and Windows generic x86-64 packages built from the final release source |
| Haswell/AVX2 binary | PASS | Linux and Windows `target-cpu=haswell` packages built from the final release source |
| Linux release startup | PASS | Generic and Haswell binaries execute `uci` and `isready` in CI |
| Windows release startup | PASS | Generic and Haswell `.exe` binaries execute and require `uciok` + `readyok` in CI |
| release artifact integrity | PASS | Every package contains `BUILD-INFO.txt` and a binary `SHA256SUMS.txt` |
| 5000-game crash-free soak | PASS | 5000/5000 paired self-play games completed with Fastchess recovery disabled; UCI compliance passed before and after |
| independent tournament-manager compatibility | PASS | Fastchess and official Cute Chess 1.5.1 both run the engine; Cute Chess completed two real repeating `40/15:00` games |
| pinned research dependencies | PASS | Fastchess, Stockfish opening-book source and Cute Chess release are pinned; downloaded Cute Chess binary is SHA-256 verified |
| reproducible Rust toolchain | PASS | Rust is pinned to 1.97.1 |
| post-merge main CI | PASS | Blocking rustfmt, check, strict Clippy, release tests, perft and deterministic benchmark passed on the release line |

## v0.3.0-rc.1 evidence captured on 2026-08-25

- Blocking CI passed formatting, checks, strict Clippy, release tests, perft and
  deterministic benchmark on the frozen candidate source.
- The exact RC STS v6 rerun scored 69,881/118,800 (58.822%) over 1,188
  positions at 100,000 nodes per position.
- A no-recovery self-play soak completed 1,000/1,000 games without a crash,
  illegal move or protocol failure; Fastchess UCI compliance passed before and
  after the match.
- Official Cute Chess 1.5.1 completed four repeating `40/4` games and the
  engine restarted cleanly after the tournament.
- All four Linux/Windows generic/Haswell preflight packages passed the
  interactive UCI handoff and package-local checksum verification. The exact
  `v0.3.0-rc.1` tag rebuilt all four successfully, and all release assets passed
  a clean post-publication checksum verification.
- A pinned Stockfish 18 limited-strength gauntlet placed the candidate between
  its 1900 and 2200 `UCI_Elo` settings at `2+0.02` over 100 games per level.
  This is a local bracket, not a CCRL rating.
- Against the locked v0.2.0 baseline, the candidate scored 168 W / 125 L /
  107 D over 400 games at `2+0.02`: +37.49 +/- 28.14 Elo and 99.58% LOS. This
  supports an improvement at that short control without making a 40/15 claim.

This is internal release-candidate evidence. The repository is private, the
candidate has not been submitted to CCRL, and no CCRL rating is claimed.
The private prerelease is frozen at
https://github.com/oaki/mikicaChessEngine/releases/tag/v0.3.0-rc.1.

## v0.3.0 post-RC promotion evidence captured on 2026-08-25

- 5,000/5,000 no-recovery Fastchess games completed on the exact RC tag with
  UCI compliance passing before and after the match.
- At `5+0.05` against locked v0.2.0, the RC scored 48 W / 28 L / 24 D over
  100 games: +70.44 +/- 48.46 Elo and 99.84% LOS.
- Official Cute Chess 1.5.1 completed two games at real repeating `40/15:00`:
  mate after 74 moves and insufficient-material draw after 83 moves. No time or
  protocol failure occurred, and the engine restarted cleanly afterward.

Exact workflow links and parameters are in `docs/STABLE-RELEASE.md`.

## v0.2.0 evidence captured on 2026-08-12

### Stability soak

- 500 paired openings / **1000 completed games**.
- Fastchess built from pinned source commit.
- Official Stockfish opening suite from pinned source commit.
- Recovery deliberately disabled.
- No illegal-move, crash, disconnect or protocol-failure gate triggered.
- UCI compliance passed before and after the match.
- Workflow verified that the PGN contained exactly 1000 games.

### Independent repeating-control test

- Official **Cute Chess 1.5.1** AppImage, SHA-256 verified.
- Four complete self-play games.
- `tc=40/4`, a shortened repeating-control analogue of the CCRL 40-move period.
- No time loss, illegal move, crash or protocol failure.
- Engine successfully restarted and answered `uci` / `isready` after the tournament.

### v0.2 hardening strength regression

Against the locked `release/v0.1.0` baseline:

```text
200 games, 1+0.01:
76 W / 72 L / 52 D
+6.95 Elo +/- 25.95

100 games, 5+0.05:
37 W / 38 L / 25 D
-3.47 Elo +/- 47.96
```

The hardening campaign therefore showed no meaningful playing-strength regression.

### State/property coverage

CI additionally runs deterministic randomized legal playouts that verify:

- make/unmake restores the exact FEN;
- incremental Zobrist keys match a board rebuilt from FEN;
- incremental evaluation state matches the rebuilt board;
- complete history unwind returns to the initial position;
- legal UCI move text serializes and reparses to the same move.

### Final release packaging

The v0.2 release workflow completed all four target jobs successfully:

- Linux x86-64 generic;
- Linux x86-64 Haswell/AVX2;
- Windows x86-64 generic;
- Windows x86-64 Haswell/AVX2.

Both Linux binaries and both Windows binaries passed real UCI startup checks on their native CI operating system. Package-local binary checksums were then independently verified after downloading the artifacts. The downloaded Linux generic package also returned `mikicaChessEngine 0.2.0`, `uciok`, `readyok`, start-position perft-4 `197281`, and a legal search `bestmove` outside the build workspace.

## 1CPU tester handoff settings

- `Threads=1`
- pondering off
- tester-controlled `Hash`
- `Move Overhead=30` ms by default; increase on unusually high-latency or heavily loaded systems
- generic x86-64 package as the compatibility default
- Haswell/AVX2 package only when the target CPU is known to support it
- no engine-side Syzygy option is advertised in v0.3.0

## Future 4CPU gate

A future 4CPU handoff has a non-negotiable requirement: `Threads=4` must show useful wall-clock scaling and survive its own long soak on hardware that actually exposes at least four CPUs. Merely starting four workers is insufficient. The first independent-worker design failed this requirement and was rejected.

## Local CCRL-like validation profile

The exact CCRL benchmark normalization is controlled by CCRL, so local matches cannot reproduce the rating list perfectly. Local validation should reproduce the important behavioral constraints:

- pondering: off
- paired openings / reversed colors
- same external opening book for both engines
- no engine-specific opening book
- no persistent learning
- fixed CPU affinity where possible
- fixed thread count
- fixed hash allocation
- repeating move-period time control for final protocol confirmation

During development, use shorter paired matches for screening and only promote successful patches to longer-time-control tests.

## Submission status

**v0.3.0 1CPU status: internal correctness, packaging, strength-regression,
5,000-game stability and real repeating 40/15 gates are complete.** Formal
CCRL handoff still requires a public immutable download and remains an external
CCRL/testing decision.

**4CPU status: NOT READY and not advertised.**

**Engine-side Syzygy: NOT IMPLEMENTED in v0.3.0 and not advertised.**
