# Changelog

## 0.3.0 — 2026-08-25

Stable single-thread release focused on measured search improvements,
reproducible diagnostics and exact-binary release validation. Promoted from
`v0.3.0-rc.1` after the post-RC gates below passed on the frozen engine source.

### Added

- Guarded null-move pruning with zugzwang/material guards and deeper-node
  verification.
- Conservative reverse futility pruning at shallow cut nodes.
- Fail-soft aspiration windows with a confirmed 64-centipawn initial window.
- Lock-free atomic transposition-table storage suitable for safe future sharing.
- Incremental pawn bitboards and pawn-state consistency tests.
- Fixed-node EPD/STS benchmark runner with SAN/UCI `bm`, `am` and weighted STS
  scoring support.
- Pinned STS v6 download helper and a 1,188-position, 100,000-node baseline.
- Exact-node search regression coverage.
- Interactive release-binary UCI handoff test covering depth, fixed nodes,
  movetime, clock allocation, infinite search and cancellation.
- Pinned GitHub Actions and Rust 1.97.1 in all CI, strength, soak,
  compatibility and release workflows.
- Pinned Stockfish 18 limited-strength reference gauntlet for conservative
  strength bracketing.

### Measured decisions

- E011 guarded null-move pruning was confirmed and merged.
- E013b aspiration windows were confirmed and merged.
- E012 SMP, E014 qsearch delta pruning, E015 SEE ordering, E016 history gravity
  and E017 guarded LMR were measured and rejected rather than advertised.
- A pinned Stockfish 18 limited-strength gauntlet at `2+0.02` scored 98.5%,
  75.5%, 55.0% and 30.0% against `UCI_Elo` 1320, 1600, 1900 and 2200
  respectively. This brackets the candidate for that test only and is not a
  CCRL rating or an unrestricted-Stockfish comparison.
- Against the locked v0.2.0 baseline, the candidate scored 168 W / 125 L /
  107 D over 400 games at `2+0.02` (+37.49 +/- 28.14 Elo, 99.58% LOS).

### Post-RC promotion gates

- A 5,000-game Fastchess self-play soak completed 5,000/5,000 games with
  recovery disabled and UCI compliance passing before and after the match.
- Against the locked v0.2.0 baseline at `5+0.05`, the RC scored 48 W / 28 L /
  24 D over 100 games (+70.44 +/- 48.46 Elo, 99.84% LOS).
- Official Cute Chess 1.5.1 completed two full repeating `40/15:00` games on
  the exact RC tag: mate after 74 moves and insufficient-material draw after
  83 moves, with no time/protocol failure and a clean post-tournament restart.

### Explicit limitations

- One search thread only; `Threads` remains fixed at 1.
- No NNUE, engine-side Syzygy probing, internal opening book or persistent
  learning.
- This release is not a claim of Stockfish parity and is not a formal CCRL
  submission.

## 0.2.0 — 2026-08-12

Stable **single-thread UCI production hardening release**.

### Added

- UCI `Move Overhead` option, default 30 ms.
- Dedicated repeating-control-aware time allocator using `movestogo`.
- Deterministic randomized property tests for make/unmake, FEN, Zobrist keys, evaluation state and UCI move round-trips.
- Transactional `position ... moves` parsing: an invalid sequence no longer partially mutates the active board.
- Stricter FEN validation for duplicate same-color kings and invalid fullmove number zero.
- 1,000-game no-recovery Fastchess stability soak.
- Independent official Cute Chess 1.5.1 repeating-control compatibility gate.
- Blocking rustfmt CI gate in addition to strict Clippy, release tests, perft and deterministic benchmark.
- Windows as well as Linux real UCI startup testing for packaged generic/Haswell builds.
- `BUILD-INFO.txt` and binary `SHA256SUMS.txt` in every release artifact.

### Strength / regression evidence

v0.2.0 versus locked `release/v0.1.0`:

```text
200 games, 1+0.01: 76 W / 72 L / 52 D, +6.95 Elo +/- 25.95
100 games, 5+0.05: 37 W / 38 L / 25 D, -3.47 Elo +/- 47.96
```

No meaningful strength regression was detected.

### Explicit non-features

- `Threads > 1` is **not** advertised. The first safe independent-worker SMP prototype was rejected after losing 17-134-49 to `Threads=1` over 200 games on a 2-CPU runner (`-232.79 +/- 47.50 Elo`).
- Engine-side Syzygy probing is not implemented or advertised in v0.2.0.
- No internal opening book and no persistent learning.

## 0.1.0 — 2026-08-12

First stable single-thread UCI baseline with a verified evaluation-strength gain.

The merged evaluation improvement combined rook open/semi-open-file bonuses with a phase-scaled king pawn-shield term.

Direct production validation against the pre-improvement baseline:

```text
500 games, 1+0.01: 240 W / 110 L / 150 D, +92.46 Elo +/- 24.94
100 games, 5+0.05: 44 W / 31 L / 25 D, +45.42 Elo +/- 54.85
```
