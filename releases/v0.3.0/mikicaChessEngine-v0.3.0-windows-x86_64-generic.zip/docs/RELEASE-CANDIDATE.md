# v0.3.0-rc.1 release candidate

This document freezes the exact release-candidate scope and collects evidence
that applies to the candidate itself. Historical v0.2 evidence is useful context
but does not replace rerunning release gates after the source changed.

## Scope

- Version: `0.3.0-rc.1`
- Tag: `v0.3.0-rc.1` at release commit
  `c6dcabf637975f70149740ca9c5a5da844910d90`
- Protocol/configuration: UCI, one thread, pondering off
- Packages: Linux and Windows x86-64 generic plus Haswell/AVX2
- Rust: 1.97.1
- Frozen engine source: `c82c1cd59d83e4db2610b3954e3b377df30587ee`
- Strength claim: stronger than the locked v0.2 baseline at the tested
  `2+0.02` control, supported by the paired candidate match below
- Non-claim: no Stockfish parity, CCRL rating, multi-thread strength, NNUE or
  engine-side Syzygy

## Required gates

| Gate | Required result | RC evidence |
|---|---|---|
| format/check/strict Clippy/release tests | PASS | [CI run 32823651474](https://github.com/oaki/mikicaChessEngine/actions/runs/32823651474) |
| start-position perft 4 | 197281 | [CI run 32823651474](https://github.com/oaki/mikicaChessEngine/actions/runs/32823651474) |
| deterministic depth-4 bench | 40202 / `2476681a0e3df97d` | [CI run 32823651474](https://github.com/oaki/mikicaChessEngine/actions/runs/32823651474) |
| STS v6 fixed-node baseline | 69881/118800 at 100k nodes | exact RC rerun: 58.822%, 118,800,000 nodes |
| interactive UCI handoff | PASS on all four packaged binaries | PASS on exact tag, [run 32825310043](https://github.com/oaki/mikicaChessEngine/actions/runs/32825310043) |
| Fastchess UCI compliance | PASS before and after soak | [soak run 32823457044](https://github.com/oaki/mikicaChessEngine/actions/runs/32823457044) |
| stability soak | 1000/1000 games, no recovery/failure | PASS: 386 W / 391 L / 223 D, [run 32823457044](https://github.com/oaki/mikicaChessEngine/actions/runs/32823457044) |
| independent tournament manager | Cute Chess repeating `40/4` PASS | PASS: 4/4 games, [run 32823459113](https://github.com/oaki/mikicaChessEngine/actions/runs/32823459113) |
| paired strength vs v0.2 | no regression; record W/D/L and interval | PASS: 168 W / 125 L / 107 D, +37.49 +/- 28.14 Elo, [run 32823461730](https://github.com/oaki/mikicaChessEngine/actions/runs/32823461730) |
| reference strength bracket | record fixed Stockfish 18 UCI-Elo gauntlet | PASS: score above 50% at 1900 and below 50% at 2200, [run 32823211356](https://github.com/oaki/mikicaChessEngine/actions/runs/32823211356) |
| package metadata/checksums | PASS for four artifacts | exact-tag build and clean release-download verification PASS, [run 32825310043](https://github.com/oaki/mikicaChessEngine/actions/runs/32825310043) |
| GitHub prerelease | immutable tag and four downloadable packages | PASS: [v0.3.0-rc.1](https://github.com/oaki/mikicaChessEngine/releases/tag/v0.3.0-rc.1) |

## Promotion rule

Create the tag only after all pre-tag gates pass. The exact-tag package,
checksum and handoff rows are post-tag gates: do not create the GitHub
prerelease unless they pass. A noisy strength estimate may be reported
honestly, but a demonstrated regression, crash, illegal move, timeout, package
startup failure or checksum mismatch blocks the RC.

The repository remains private. Consequently this RC can be a frozen GitHub
prerelease for project testing, but it is not yet the public immutable download
required for a formal CCRL submission.

The published prerelease contains Linux and Windows x86-64 generic and
Haswell/AVX2 archives plus an aggregate `SHA256SUMS.txt`. All five assets were
downloaded again into a clean directory after publication; every archive hash
matched the published checksum file.

## Evidence interpretation

The stability result is a crash/protocol gate, not a strength measurement. The
two sides used identical engine source and the final score of 49.75% is
consistent with that setup. The Stockfish limited-strength gauntlet is only a
local bracket under its stated short time control; it must not be presented as
a CCRL rating or as evidence of parity with unrestricted Stockfish.

The pinned Stockfish 18 gauntlet used 100 games per level, paired openings,
`2+0.02`, one thread and 32 MiB hash:

| Stockfish 18 `UCI_Elo` | Candidate W/L/D | Score |
|---:|---:|---:|
| 1320 | 98/1/1 | 98.5% |
| 1600 | 72/21/7 | 75.5% |
| 1900 | 48/38/14 | 55.0% |
| 2200 | 23/63/14 | 30.0% |

This brackets the candidate between the 1900 and 2200 limited-strength
settings for this exact test. It is deliberately reported as a range because
the small samples and Stockfish's strength-limiting behavior do not justify a
single portable rating.

The direct candidate regression match used commit
`c82c1cd59d83e4db2610b3954e3b377df30587ee` against the locked v0.2.0 commit
`a13ee787a6bda93227f685a30c5687fa846c1db4`, 200 paired openings, `2+0.02`, one
thread and 32 MiB hash. The candidate scored 168 W / 125 L / 107 D over 400
games (55.38%), an estimated +37.49 +/- 28.14 Elo with 99.58% likelihood of
superiority. This supports a strength improvement at the tested short time
control; it is not automatically transferable to CCRL 40/15.

## Post-RC promotion result

The unchanged RC chess source subsequently passed a 5,000-game no-recovery
burn-in, a 100-game `5+0.05` regression match against v0.2.0 and two complete
official Cute Chess games at real repeating `40/15:00`. The full evidence and
stable-release gates are recorded in [`STABLE-RELEASE.md`](STABLE-RELEASE.md).
