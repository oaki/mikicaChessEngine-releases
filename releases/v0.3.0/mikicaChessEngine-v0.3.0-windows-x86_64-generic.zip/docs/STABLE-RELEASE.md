# v0.3.0 stable release

This document freezes the stable single-thread release scope and records the
promotion evidence collected on the exact `v0.3.0-rc.1` engine source. The only
engine-facing change after the RC is the package/UCI version string from
`0.3.0-rc.1` to `0.3.0`.

## Scope

- Version/tag: `v0.3.0`
- Promoted RC tag: `v0.3.0-rc.1`
- RC release commit: `c6dcabf637975f70149740ca9c5a5da844910d90`
- Frozen chess source: `c82c1cd59d83e4db2610b3954e3b377df30587ee`
- Protocol/configuration: UCI, one thread, pondering off
- Packages: Linux and Windows x86-64 generic plus Haswell/AVX2
- Rust: 1.97.1
- Non-claims: no unrestricted-Stockfish parity, CCRL rating, multi-thread
  strength, NNUE or engine-side Syzygy

## Promotion evidence

| Gate | Result | Evidence |
|---|---|---|
| RC correctness/release gates | PASS | [`v0.3.0-rc.1` record](RELEASE-CANDIDATE.md) |
| no-recovery burn-in | PASS: 5,000/5,000 games | [run 32828563125](https://github.com/oaki/mikicaChessEngine/actions/runs/32828563125) |
| UCI compliance after burn-in | PASS | [run 32828563125](https://github.com/oaki/mikicaChessEngine/actions/runs/32828563125) |
| longer strength vs v0.2.0 | PASS: 48 W / 28 L / 24 D at `5+0.05` | [run 32828565411](https://github.com/oaki/mikicaChessEngine/actions/runs/32828565411) |
| estimated longer-control gain | +70.44 +/- 48.46 Elo, 99.84% LOS | [run 32828565411](https://github.com/oaki/mikicaChessEngine/actions/runs/32828565411) |
| real repeating `40/15:00` | PASS: 2/2 complete games | [run 32828568329](https://github.com/oaki/mikicaChessEngine/actions/runs/32828568329) |
| post-tournament UCI restart | PASS | [run 32828568329](https://github.com/oaki/mikicaChessEngine/actions/runs/32828568329) |
| release-preparation CI | PASS on frozen engine source | [run 32839485645](https://github.com/oaki/mikicaChessEngine/actions/runs/32839485645) |
| exact-tag packages/handoff/checksums | required before release | pending |
| private GitHub stable release | four archives plus checksums | pending |

## Detailed post-RC results

The 5,000-game burn-in used paired Stockfish opening-suite positions,
`0.2+0.002`, one thread, 32 MiB hash and no recovery. It completed 1,932 W /
1,884 L / 1,184 D (50.48%) in 21:07. The score is not a strength claim because
both sides used identical source. No crash, illegal move, disconnect or
protocol failure was detected, the PGN contained exactly 5,000 games, and
Fastchess UCI compliance passed afterward.

The longer paired regression match used the exact RC tag against the locked
v0.2.0 commit `a13ee787a6bda93227f685a30c5687fa846c1db4`, 50 paired
openings, `5+0.05`, one thread and 32 MiB hash. The RC scored 48 W / 28 L /
24 D (60.0%), estimated +70.44 +/- 48.46 Elo with 99.84% likelihood of
superiority. Together with the 400-game `2+0.02` result, this supports a real
improvement over v0.2.0 while remaining short of a CCRL rating claim.

Official Cute Chess 1.5.1 then ran two self-play games with `TimeControl
"40/900"`, equivalent to repeating 40 moves in 15 minutes. Game one ended in
mate after 74 full moves; game two ended by insufficient mating material after
83 full moves. There was no time loss, crash, disconnect, illegal move or
protocol error, and a fresh post-tournament process returned `uciok` and
`readyok`.

## External-release limitation

The repository remains private. A private stable GitHub Release is useful as a
frozen project artifact, but it is not the public immutable download needed for
formal CCRL submission. Repository visibility or public redistribution must be
an explicit owner decision.
